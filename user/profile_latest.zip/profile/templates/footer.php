  <div class="footer-wrapper style-3">
                    <footer class="type-1">
                       
                        <div class="footer-bottom-navigation">
                            <div class="cell-view">
                                <div class="footer-links">
                                    <a href="index.php">Home</a>
                                    <a href="complaint.php">Complain</a>
                                    <a href="aboutus.php">About Us</a>
                                    <a href="contactus.php">Contact Us</a>
                                    
                                </div>
                                <div class="copyright">Created with by <a href="http://sukem.in/">Sukem Tech Lab</a>. All right reserved</div>
                            </div>
                                                    </div>
                    </footer>
                </div>